import java.awt.*;
import java.text.NumberFormat;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.ChangeEvent;

/** Aplicação desktop para simular o abastecimento em um posto de gasolina. */
public class PostoGasolinaApp extends JFrame {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final Locale BRASIL = new Locale("pt", "BR");
    private static final NumberFormat MOEDA = NumberFormat.getCurrencyInstance(BRASIL);
    private final Map<String, Double> precos = new LinkedHashMap<>();
    private final JComboBox<String> combustivelBox;
    private final JSpinner litrosSpinner;
    private final JLabel precoLabel = new JLabel();
    private final JLabel totalLabel = new JLabel();
    private final JLabel statusLabel = new JLabel("Pronto para abastecer");
    private final JProgressBar progresso = new JProgressBar();
    private final JButton abastecerButton = new JButton("Iniciar abastecimento");

    public PostoGasolinaApp() {
        super("Posto Gabriel | Abastecimento");
        precos.put("Gasolina", 6.82);
        precos.put("Diesel S-10", 7.20);
        precos.put("Etanol", 4.36);

        combustivelBox = new JComboBox<>(precos.keySet().toArray(new String[0]));
        litrosSpinner = new JSpinner(new SpinnerNumberModel(10.0, 0.1, 500.0, 0.1));
        configurarJanela();
        atualizarValores();
    }

    private void configurarJanela() {
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(680, 535));
        setSize(760, 580);
        setLocationRelativeTo(null);

        JPanel raiz = new JPanel(new BorderLayout(0, 20));
        raiz.setBackground(new Color(15, 23, 42));
        raiz.setBorder(new EmptyBorder(28, 36, 28, 36));
        setContentPane(raiz);

        raiz.add(criarCabecalho(), BorderLayout.NORTH);
        raiz.add(criarConteudo(), BorderLayout.CENTER);
    }

    private JComponent criarCabecalho() {
        JPanel cabecalho = new JPanel(new BorderLayout());
        cabecalho.setOpaque(false);
        JLabel titulo = new JLabel("POSTO AURORA");
        titulo.setForeground(Color.WHITE);
        titulo.setFont(new Font("SansSerif", Font.BOLD, 25));
        JLabel subtitulo = new JLabel("Abastecimento rápido, claro e seguro");
        subtitulo.setForeground(new Color(148, 163, 184));
        subtitulo.setFont(new Font("SansSerif", Font.PLAIN, 14));
        JPanel textos = new JPanel();
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));
        textos.setOpaque(false);
        textos.add(titulo);
        textos.add(Box.createVerticalStrut(5));
        textos.add(subtitulo);
        cabecalho.add(textos, BorderLayout.WEST);

        JLabel icone = new JLabel("⛽", SwingConstants.CENTER);
        icone.setFont(new Font("SansSerif", Font.PLAIN, 38));
        cabecalho.add(icone, BorderLayout.EAST);
        return cabecalho;
    }

    private JComponent criarConteudo() {
        JPanel painel = new JPanel(new GridBagLayout());
        painel.setBackground(new Color(30, 41, 59));
        painel.setBorder(new CompoundBorder(new LineBorder(new Color(51, 65, 85)), new EmptyBorder(26, 28, 24, 28)));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(7, 0, 7, 0);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 1;
        int linha = 0;

        adicionar(painel, rotulo("Combustível"), c, linha++);
        estilizarCampo(combustivelBox);
        adicionar(painel, combustivelBox, c, linha++);
        adicionar(painel, rotulo("Quantidade (litros)"), c, linha++);
        estilizarCampo(litrosSpinner);
        adicionar(painel, litrosSpinner, c, linha++);

        JPanel resumo = new JPanel(new GridLayout(1, 2, 14, 0));
        resumo.setOpaque(false);
        resumo.add(cartao("PREÇO POR LITRO", precoLabel));
        resumo.add(cartao("TOTAL ESTIMADO", totalLabel));
        c.insets = new Insets(15, 0, 16, 0);
        adicionar(painel, resumo, c, linha++);

        estilizarBotao(abastecerButton, new Color(37, 99, 235));
        abastecerButton.addActionListener(e -> iniciarAbastecimento());
        c.insets = new Insets(0, 0, 10, 0);
        adicionar(painel, abastecerButton, c, linha++);

        progresso.setStringPainted(true);
        progresso.setString("Aguardando");
        progresso.setForeground(new Color(34, 197, 94));
        progresso.setBackground(new Color(51, 65, 85));
        adicionar(painel, progresso, c, linha++);
        statusLabel.setForeground(new Color(148, 163, 184));
        statusLabel.setFont(new Font("SansSerif", Font.PLAIN, 13));
        adicionar(painel, statusLabel, c, linha);

        combustivelBox.addActionListener(e -> atualizarValores());
        litrosSpinner.addChangeListener((ChangeEvent e) -> atualizarValores());
        return painel;
    }

    private void adicionar(JPanel painel, JComponent componente, GridBagConstraints c, int linha) {
        c.gridx = 0;
        c.gridy = linha;
        painel.add(componente, c);
    }

    private JLabel rotulo(String texto) {
        JLabel label = new JLabel(texto);
        label.setForeground(new Color(226, 232, 240));
        label.setFont(new Font("SansSerif", Font.BOLD, 13));
        return label;
    }

    private JPanel cartao(String titulo, JLabel valor) {
        JPanel cartao = new JPanel();
        cartao.setLayout(new BoxLayout(cartao, BoxLayout.Y_AXIS));
        cartao.setBackground(new Color(15, 23, 42));
        cartao.setBorder(new EmptyBorder(13, 15, 13, 15));
        JLabel nome = new JLabel(titulo);
        nome.setForeground(new Color(148, 163, 184));
        nome.setFont(new Font("SansSerif", Font.BOLD, 10));
        valor.setForeground(new Color(255, 255, 255));
        valor.setFont(new Font("SansSerif", Font.BOLD, 19));
        cartao.add(nome);
        cartao.add(Box.createVerticalStrut(5));
        cartao.add(valor);
        return cartao;
    }

    private void estilizarCampo(JComponent componente) {
        componente.setFont(new Font("SansSerif", Font.PLAIN, 15));
        componente.setPreferredSize(new Dimension(0, 38));
    }

    private void estilizarBotao(JButton botao, Color cor) {
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE);
        botao.setFont(new Font("SansSerif", Font.BOLD, 14));
        botao.setFocusPainted(false);
        botao.setBorder(new EmptyBorder(12, 15, 12, 15));
        botao.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private void atualizarValores() {
        double preco = precos.get((String) combustivelBox.getSelectedItem());
        double litros = ((Number) litrosSpinner.getValue()).doubleValue();
        precoLabel.setText(MOEDA.format(preco));
        totalLabel.setText(MOEDA.format(preco * litros));
    }

    private void iniciarAbastecimento() {
        double litros = ((Number) litrosSpinner.getValue()).doubleValue();
        if (litros <= 0) {
            JOptionPane.showMessageDialog(this, "Informe uma quantidade maior que zero.", "Quantidade inválida", JOptionPane.WARNING_MESSAGE);
            return;
        }
        abastecerButton.setEnabled(false);
        combustivelBox.setEnabled(false);
        litrosSpinner.setEnabled(false);
        progresso.setValue(0);
        int etapas = Math.max(1, (int) Math.ceil(litros));
        Timer timer = new Timer(Math.max(25, 1100 / etapas), null);
        timer.addActionListener(e -> {
            int atual = Math.min(etapas, progresso.getValue() + 1);
            int percentual = (int) Math.round(atual * 100.0 / etapas);
            progresso.setValue(atual);
            progresso.setMaximum(etapas);
            progresso.setString(percentual + "%");
            statusLabel.setText(String.format("Abastecendo... %.1f L de %.1f L", Math.min((double) atual, litros), litros));
            if (atual == etapas) {
                timer.stop();
                finalizarAbastecimento(litros);
            }
        });
        timer.start();
    }

    private void finalizarAbastecimento(double litros) {
        String combustivel = (String) combustivelBox.getSelectedItem();
        double preco = precos.get(combustivel);
        double total = litros * preco;
        statusLabel.setText("Abastecimento concluído. Recibo gerado!");
        abastecerButton.setEnabled(true);
        combustivelBox.setEnabled(true);
        litrosSpinner.setEnabled(true);
        JOptionPane.showMessageDialog(this,
                "RECIBO DE PAGAMENTO\n\n" +
                "Combustível: " + combustivel + "\n" +
                "Quantidade: " + String.format(BRASIL, "%.2f L", litros) + "\n" +
                "Preço por litro: " + MOEDA.format(preco) + "\n" +
                "──────────────────────────\n" +
                "TOTAL A PAGAR: " + MOEDA.format(total),
                "Abastecimento concluído", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new PostoGasolinaApp().setVisible(true));
    }
}
